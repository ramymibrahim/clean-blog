<?php
function canAdd(){
    return true;
}

function uploadImage($image){
    return 'img/1.jpg';
}